# problem-solving-lab-2
script.js learning how to use java script 
